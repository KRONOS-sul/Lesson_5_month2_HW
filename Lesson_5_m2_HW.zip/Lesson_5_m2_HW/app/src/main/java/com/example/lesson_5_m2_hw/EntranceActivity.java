package com.example.lesson_5_m2_hw;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class EntranceActivity extends AppCompatActivity {
Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entrance);
        button = findViewById(R.id.search_close_btn_enter_by_email);

        button.setOnClickListener(view ->
                startActivity(new Intent(EntranceActivity.this, MainActivity.class)));
    }


}